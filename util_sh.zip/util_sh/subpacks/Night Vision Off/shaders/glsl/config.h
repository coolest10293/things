#ifndef UTILCFG
#define UTILCFG

//#define NIGHT_VISON
#define CHUNK_BORDER//go terain.fsh l117 for more settings
#define RSLV
#define COMPASS 250.0//size
#define SP_CHECKER//go terain.fsh l138 for more settings

#endif
